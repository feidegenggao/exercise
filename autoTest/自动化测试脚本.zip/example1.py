#-*- coding: UTF-8 -*-
#!/usr/bin/python 
import re,sys,pxssh,pexpect
from session import *

s = session('192.168.1.13','root','uestc8020')
s.cmd('cd /root')
s.cmd('ls -l')
s.close()





